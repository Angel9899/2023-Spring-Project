# Homepage
![The website homepage](homepage.png)

# User actions menu(logged out)
![User actions menu(logged out)](user_actions_accountless.png)

# User actions menu(logged in)
![User actions menu(logged in)](user_actions_accounted.png)

# User register menu
![The register menu](register_menu.png)

# User login menu
![The login menu](login_menu.png)

# User workspace page
![User workspace page](workspace.png)